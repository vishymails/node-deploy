module.exports = {
    ryan: {
      name: "Ryan Dahl",
      irc: "ryah",
      twitter: "ryah",
      github: "ry",
      location: "San Francisco, USA",
      description: "Creator of node.js"
    },
    isaac: {
      name: "Isaac Schlueter",
      irc: "isaacs",
      twitter: "izs",
      github: "isaacs",
      location: "San Francisco, USA", 
      description: "Former project gatekeeper, CTO npm, Inc."
    },
    timothy: {
      name: "Timothy J Fontaine",
      irc: "tjfontaine",
      twitter: "tjfontaine",
      github: "tjfontaine",
      location: "Alameda, USA", 
      description: "Project gatekeeper"
    },
    tj: { 
      name: "TJ Holowaychuk",
      irc: "tjholowaychuk",
      twitter: "tjholowaychuk",
      github: "visionmedia",
      location: "Victoria, BC, Canada",
      description: "Author of express, jade and many other modules"
    },
    felix: {
      name: "Felix Geisendorfer",
      irc: "felixge",
      twitter: "felixge",
      github: "felixge",
      location: "Berlin, Germany",
      description: "Author of formidable, active core developer"
    }
  };