var fs = require('fs')

fs.appendFile('myfile1.txt', "Hello Oracle", function (err) {
    if(err) throw err;
    console.log('file saved');
});


fs.open('myfile2.txt', 'w', function (err) {
    if(err) throw err;
    console.log('file saved');
});


fs.writeFile('myfile3.txt', "Hello Oracle3", function (err) {
    if(err) throw err;
    console.log('file saved');
});