const express = require('express');

const app = express();

app.use("/", (req, res, next) => {
    console.log("This code always runs ");
    next();
});


app.use("/add-product", (req, res, next) => {
    console.log("another middleware call ");
    res.send('<h1> Add Product </h1>');
    
});

app.use("/", (req, res, next) => {
    console.log("another call for root  ");
    res.send('<h1> Reponse from root Product </h1>');
   
});

app.listen(8080);

