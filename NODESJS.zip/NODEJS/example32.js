var fs = require("fs");

fs.mkdir('./test', function(err) {
    if(err) {
        return console.error(err);

    }
    console.log("Directory created ");
});



fs.readdir("c:/CLASSROOM/", function(err, files) {
    if(err) {
        return console.error(err);

    }
    files.forEach(function (file) {
        console.log(file);
    });
});


fs.rmdir("./test", function(err) {
    if(err) {
        return console.error(err);

    }
    console.log("test dir deleted ");
});