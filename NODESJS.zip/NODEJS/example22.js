var http = require('http');
var dt = require('./myModule');



http.createServer(function(req, res) {
    res.writeHead(200, {'Content-Type' : "text/html"});
    res.end("The Date and Time are currently " + dt.myDateTime());
    res.end();
}).listen(8080);