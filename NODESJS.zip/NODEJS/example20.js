var express = require('express');
var app = express();
var url = require('url');

app.get('/' , function(req, res) {
    var queryObject = url.parse(req.url, true).query;
    var greeting = queryObject.greeting || 'DefaultString';

    res.end("This is my express app : " + greeting)
});

app.listen(8080, function() {
    console.log('Server listening on port 8080');
});