var emitter = require('events').EventEmitter;

var em = new emitter();

em.addListener('FirstEvent', function (data) {
    console.log('First Subscriber : ' + data);
});


em.on('SecondEvent', function(data) {
    console.log('Second Subscriber : ' + data);
});

em.emit('FirstEvent', "This is my first event emitter sample");

em.emit('SecondEvent', 'Second event emitter');