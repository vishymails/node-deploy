const express = require('express');
const bodyparser = require('body-parser');

const app = express();


app.use(bodyparser.urlencoded({extended : false }));


app.use("/", (req, res, next) => {
    res.send("<h1> task completed</h1>");
});


app.use("/add-product", (req, res, next) => {
    console.log("another middleware call ");
    res.send('<form action="/product" method="POST"> <input type="text" name="title"> <button type="submit"> Add Product</button></form>');
    
});

app.use("/product", (req, res, next) => {
    console.log(req.body);
    res.redirect('/');
   
});

app.listen(8080);

