const { application } = require('express');
const express = require('express')

const PORT = 9000;
const HOST = '0.0.0.0';

const app = express();

application.get('/', (req, res) => {
    res.send("<h1>Hello Oracle </h1>");
});

app.listen(PORT, HOST);

console.log("Server Running - 9000");
