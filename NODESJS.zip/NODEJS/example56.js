var os = require('os');

console.log('endianness : ' + os.endianness());

console.log('type : ' + os.type());

console.log('platform : ' + os.platform());

console.log('total memory : ' + os.totalmem());


console.log('free memory : ' + os.freemem());

console.log('temp directory : ' + os.tmpdir());

console.log('hostname : ' + os.hostname());

console.log('architecture : ' + os.arch());

console.log('release : ' + os.release());

console.log('cpus : ' + os.cpus());

console.log('network interfaces : ' + os.networkInterfaces());

