var Http = require('http');

    Router = require('router');
    router = new Router() ;

    server=Http.createServer(function (request, response) {
        router(request, response, function(error) {
            if(!error) {
                response.writeHead(404);
            } else {
                console.log(error.message, error.stack);
                response.writeHead(400);
            }
            response.end('\n');
            
        });
    });

    var BodyParser = require('body-parser');
    router.use(BodyParser.text());

    var counter = 0,
        messages = {};

    function createMessage(request, response ) {
        var id = counter +=1, 
            message = request.body;

        console.log('Create Message ', id, message);
        messages[id] = message;

        response.writeHead(201, {
            'Content-Type' : 'text/plain',
            'Location' : '/message/' + id
        });
        response.end ('Message : ' + id);
    }
    router.post('/message', createMessage);


    function readMessage(request, response) {
        var id = request.params.id,
            message = messages[id];

            console.log("Read Message ", id, message);

            response.writeHead(200, {
                'Content-Type' : 'text/plain'
            });
            response.end ('Message : ' + id);
    }
    
    router.get('/message/:id', readMessage);


    function deleteMessage(request, response) {
        var id = request.params.id;

        console.log('Delete Message ', id);

        messages[id] = undefined;

        response.writeHead(204, {});

        response.end('');
    }

    router.delete('/message/:id', deleteMessage);


    function readMessages(request, response) {
        var id,
            message,
            messageList = [],
            messageString;

        for(id in messages) {
            if(!messages.hasOwnProperty(id)) {
                continue;
            }
            message = messages[id];

            // handling deleted messages 

            if(typeof message !== 'string' ) {
                continue;
            }

            messageList.push(message);
        }
        console.log('Read Messages', JSON.stringify(messageList, null, ' ' ));
        messageString = messageList.join('\n');

        response.writeHead(200, {
            'Content-Type' : 'text/plain'
        });
        response.end(messageString);
    }

    router.get('/message', readMessages);

    server.listen(8080, function () {
        console.log('Listening on port 8080');
    });