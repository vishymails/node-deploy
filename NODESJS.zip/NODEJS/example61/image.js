export class Image {
    constructor (path) {
        this.path = path;
    }
}