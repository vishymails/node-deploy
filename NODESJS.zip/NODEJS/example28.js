var fs = require('fs');

fs.unlink('myfile11.txt', function(err) {
    if(err) throw err;

    console.log("deleted");
});