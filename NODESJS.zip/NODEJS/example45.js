var Http = require('http'),
    FS = require('fs');
const { SocketAddress } = require('net');

var server = Http.createServer(handler);

server.listen(8080);


function handler(request, response) {
    var index = FS.readFileSync('example44.html');

    index = index.toString();

    response.writeHead(200, {
        'Content-Type' : 'text/html',
        'Content-length' : Buffer.byteLength(index)
    });

    response.end(index);
}


var io = require('socket.io')(server);



io.on('connection', function(socket) {
    function onTimeout() {
        socket.send('Update');
    }
    setInterval(onTimeout, 1000);
});