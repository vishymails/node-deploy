function sort(arr = [], direction = 'ascending') {
    console.log('I am planned to do sort on : ' + arr + "in : " + direction + " order ");
}

sort([3,2,1,8]);

sort([3,2,1,4,5,8], "descending");

