var values = [1, 60, 34, 30, 20, 19, 5];

function lessThan20(val) {
    return val < 20;
}

var valuesLessThan20 = values.filter(lessThan20);


console.log(values);
console.log(valuesLessThan20);