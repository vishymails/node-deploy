var companies = ['isro', 'oracle', 'citibank', 'johndeere', 'SAP', 'JP Morgan']

function changeProperties(val) {
    return val.toUpperCase();
}

console.log(companies);

var changed = companies.map(changeProperties);

console.log(changed);