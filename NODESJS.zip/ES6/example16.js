function sum(...args) {
    var total;
    total = args.reduce((acc, elem) => acc + elem, 0 );
    console.log(total);
}


sum(1,2,3);

sum(3,4,5,6,6,7,75,4,9)




var defaultColors = ["red", "green", "blue", "cyan","megenta"];

var userDefinedColors = ["yellow", "black"];

var mergedColors = [...defaultColors, ...userDefinedColors];

console.log("Merged Colors : " + mergedColors);




function printColors(first, second, third, ...others) {
    console.log('Top three colors are ' + first + "," + second + "," + third + ", others are " + others );
}

printColors("red", "green", "blue","yellow", "black","cyan","megenta");


