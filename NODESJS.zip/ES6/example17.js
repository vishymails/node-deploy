function printFirstAndSecondElement([first, second]) {
    console.log('First Element is ' + first + " Second element is " + second );
}

var array = [1, 2, 3, 4 ,5]

printFirstAndSecondElement(array);


function printSecondandFourthElement([, second, , fourth]) {
    console.log('second Element is ' + second + " fourth element is " + fourth );
}

var array = [1, 2, 3, 4 ,5]


printSecondandFourthElement(array);


var person = {
    firstName : "Ram", 
    secondName : "Kumar",
    age : 33,
    children : 2,
    profession : 'Developer'

}


function printInfo({firstName, secondName, profession}) {
    console.log(firstName + secondName + "--" + profession );
}

printInfo(person);