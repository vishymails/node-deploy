function templateFunction(name, type) {
    return `Company Name  : ${name} of 
    type : ${type} 
    from Bangalore `
}

console.log(templateFunction('SAP', 'Private LTD'));