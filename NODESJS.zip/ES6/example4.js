var companies = ['isro', 'oracle', 'citibank', 'johndeere', 'SAP', 'JP Morgan']

function print(val) {
    console.log(val);
}

companies.forEach(print);


console.log("----------------------------")


with(companies) {
    forEach(print);
}