const color = 'red';

const point = { 
    x : 10,
    y : 20,
    color,
    toString () {
        return ("x : " + this.x + " y : "+ this.y + "color : " + this.color);
    },
    ['prop_' + 42] : 42
}

console.log("The poin is : " + point );

console.log("The Dynamic property is  : " + point.prop_42);