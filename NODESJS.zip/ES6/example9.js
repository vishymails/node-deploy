var people = [
    {name : 'Ram', sal : 500000},
    {name : 'Sneha', sal : 5000000},
    {name : 'Pinku', sal : 1500000},
    {name : 'Sushi', sal : 9500000},
    {name : 'mahi', sal : 8500000},
    {name : 'Raj', sal : 200000}
];

function isAreAllHighPaid(person) {
    return person.sal > 5000000 && person.sal < 10000000;
}

var isMethod = people.some(isAreAllHighPaid);

console.log(isMethod);

