var array = [1,2, 3, 4, 5]

const sum = (acc, value) => {
    const result = acc + value;
    console.log("sum result :", result );
    return result ;
}


var sumOfArrayElements = array.reduce(sum, 0);


const product  = (acc, value) => acc * value;

var productOfArrayElements = array.reduce(product, 1);

console.log("Product result : ", productOfArrayElements);
