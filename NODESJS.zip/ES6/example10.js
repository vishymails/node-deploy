var array = [1,2,3,4];

function sum(acc, value) {
    return acc + value;
}

var sumOfArrayElements = array.reduce(sum, 0);

console.log("Sum :", sumOfArrayElements);


function mul(acc, value) {
    return acc * value;
}

var productOfArrayElements = array.reduce(mul, 1);

console.log("Mul :", productOfArrayElements);


